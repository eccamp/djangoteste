from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from main import models



def home(request):
    return render(request, "main/home.html")
