from django.db import models
from django.shortcuts import render
import django.http

# Create your models here.
class Iniciar:
    def __init__(self, palavra, tamanho):
        self._palavra = palavra
        self._tamanho = tamanho
        self._oculta = tamanho*"_"

    def pegar_palavra(request):
        palavra = request.get('texto')
        __init__(palavra)
        return render("main/home.html", {'palavra': palavra})



